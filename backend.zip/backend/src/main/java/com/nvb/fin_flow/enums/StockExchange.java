package com.nvb.fin_flow.enums;

public enum StockExchange {
    HOSE,
    HNX,
    UPCOM
}
