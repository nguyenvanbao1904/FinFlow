package com.nvb.fin_flow.enums;

public enum RecurringType {
    WEEKLY,
    MONTHLY,
    YEARLY
}
