package com.nvb.fin_flow.enums.NonBankingType;

public enum NonBankingIncomeStatementsType {
    PROFIT_AFTER_TAX,
    NET_REVENUE

}
