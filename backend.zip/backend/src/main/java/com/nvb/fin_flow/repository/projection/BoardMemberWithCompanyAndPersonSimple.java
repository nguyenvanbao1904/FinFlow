package com.nvb.fin_flow.repository.projection;

public interface BoardMemberWithCompanyAndPersonSimple {
    String getId();
    String getPosition();
    String getCompany_Name();
    String getPerson_Name();
}
