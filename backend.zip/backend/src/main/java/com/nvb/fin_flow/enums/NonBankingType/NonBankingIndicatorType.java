package com.nvb.fin_flow.enums.NonBankingType;

public enum NonBankingIndicatorType {
    PE,
    PB,
    PS,
    ROE,
    ROA,
    EPS,
    BVPS,
    LNG,
    LNR,
    CPLH
}
