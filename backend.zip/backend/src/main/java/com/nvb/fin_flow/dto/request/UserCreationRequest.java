package com.nvb.fin_flow.dto.request;

import java.time.LocalDate;

import com.nvb.fin_flow.validator.DobConstraint;
import com.nvb.fin_flow.validator.PasswordConstraint;
import jakarta.validation.constraints.Size;

import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserCreationRequest {
    @Size(min = 4, message = "USERNAME_INVALID")
    String username;

    @PasswordConstraint
    String password;

    String firstName;
    String lastName;

    @DobConstraint(min = 10, message = "INVALID_DOB")
    LocalDate dob;
}
