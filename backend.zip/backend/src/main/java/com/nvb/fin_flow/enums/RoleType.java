package com.nvb.fin_flow.enums;

public enum RoleType {
    USER,
    ADMIN
}
