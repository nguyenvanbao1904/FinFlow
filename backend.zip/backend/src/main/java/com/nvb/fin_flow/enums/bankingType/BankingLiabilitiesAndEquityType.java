package com.nvb.fin_flow.enums.bankingType;

public enum BankingLiabilitiesAndEquityType {
    EQUITY,
    TOTAL_CAPITAL,
    GOV_AND_SBV_DEBT,
    DEPOSITS_BORROWINGS_OTHERS,
    DEPOSITS_FROM_CUSTOMERS,
    CONVERTIBLE_AND_OTHER_PAPERS
}
