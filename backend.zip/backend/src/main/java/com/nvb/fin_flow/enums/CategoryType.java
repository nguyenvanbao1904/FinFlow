package com.nvb.fin_flow.enums;

public enum CategoryType {
    INCOME,
    EXPENSE,
    SAVING
}