package com.nvb.fin_flow.enums;

public enum DividendType {
    CASH,
    SHARE
}
