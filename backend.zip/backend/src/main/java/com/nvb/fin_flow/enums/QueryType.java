package com.nvb.fin_flow.enums;

public enum QueryType {
    INDICATOR_VALUE,
    INCOME_STATEMENT
}
