package com.nvb.fin_flow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinFlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
